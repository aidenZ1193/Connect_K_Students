import java.util.*;
import java.lang.*;
import java.io.*;

public class Main {
    public static void main(String[] args) 
    {
//    	if(args.length < 5)
//    	{
//    		System.out.println("Invalid Parameters");
//    		System.exit(0);
//    	}
//
//    	int col = Integer.parseInt(args[0]);
//		int row = Integer.parseInt(args[1]);
//		int k = Integer.parseInt(args[2]);
//		int g = Integer.parseInt(args[3]);
//		String mode = args[4];
//		boolean debug = false;
//
//		if (args.length == 6 && args[5].equals("-d") )
//		{
//			debug = true;
    	
    	
//		}
    	
    	int col = 10;
		int row = 10;
		int k = 5;
		int g = 0;  // if g==0, then Connect-K in every possible range, if not, can only put at the bottom of the board.
		String mode ="m";
		boolean debug = true;
		GameLogic main = new GameLogic(col, row, k,g, mode, debug);
		
		main.Run();
		System.out.println("Finished");
    }
}