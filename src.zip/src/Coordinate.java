
public class Coordinate {
	int col;
	int row;
	
	public Coordinate(int col, int row) {
		this.col=col;
		this.row = row;
	}
	

}
