import java.util.*;

public class Move 
{
	public int row, col;

	public Move() 
	{
		this.col = 0;
		this.row = 0;
	}

	public Move(int col, int row) 
	{
		this.col = col;
		this.row = row;
	}
}