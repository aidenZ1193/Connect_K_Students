import java.util.*;

//The following part should be completed by students.
//Students can modify anything except the class name and exisiting functions and varibles.
public class StudentAI extends AI {

	public ArrayList<ArrayList<Integer>> Student_Board;
	public int flag = 0;

	public void Student_Board(int col, int row, int k, int g) {
		this.col = col;
		this.row = row;
		this.k = k;
		this.g = g;
		Student_Board = new ArrayList<ArrayList<Integer>>();

		for (int i = 0; i < row; i++) {
			ArrayList<Integer> temp = new ArrayList<Integer>();
			for (int j = 0; j < col; j++) {
				temp.add(0);
			}
			Student_Board.add(temp);
		}
	}

	public void Update_Board(Move move, int player) {
		if (move.col >= 0 && move.col <= col && move.row >= 0 && move.row <= row) {
			if (player == 1) {
				Student_Board.get(move.row).set(move.col, 1);
			} else {
				Student_Board.get(move.row).set(move.col, 2);
			}
		}
	}
	
	public void Update_Board_Bottom(Move move, int player) {
		if(inBound(move.row, move.col)) {
			int col_Bottom=move.col;
			int row_Bottom=row-1;
			
			while(row_Bottom>=0 && Student_Board.get(row_Bottom).get(col_Bottom)!=0) {
				row_Bottom--;
			}
			
			
			//may consider row_Bottom<0
			if(row_Bottom==-1) {
				return;
			}
			
			if(player==1) {
				Student_Board.get(row_Bottom).set(col_Bottom, 1);
			}else {
				Student_Board.get(row_Bottom).set(col_Bottom, 2);
			}
		}
	}

	public void Show_Board_information() {
		int count = 0;
		for (int i = 0; i < Student_Board.size(); i++) {
			for (int j = 0; j < Student_Board.get(i).size(); j++) {
				if (Student_Board.get(i).get(j) != 0) {
					count++;
				}
			}

		}
		System.out.println("the total number is ");
		System.out.println(count);
		System.out.println("           ");
	}

	public StudentAI(int col, int row, int k, int g) {
		super(col, row, k, g);
	}

	public Move GetMove(Move move) {
		if (g == 0) {
			if (flag == 0) {
				Student_Board(col, row, k, g);
				flag++;
			}
			Show_Board_information();
			Update_Board(move, 2);
			
			Coordinate coor = Make_Decision();

			System.out.println("AI go as: ");
			System.out.println(coor.col);
			System.out.println(coor.row);

			Move move_me = new Move(coor.col, coor.row);
			Update_Board(move_me, 1);
			Show_Board_information();
			return new Move(coor.col, coor.row);
		} else {
			if (flag == 0) {
				Student_Board(col, row, k, g);
				flag++;
			}
			Show_Board_information();
			Update_Board_Bottom(move, 2);
			
			//Coordinate coor = Make_Decision_Bottom();
			int col_cur = Make_Decision_Bottom();
			Update_Board_Bottom(new Move(0, col_cur), 1);
			Show_Board_information();
			return new Move(col_cur, 0);
		}
	}
	
	public void Show_Board_value(Object[] ee) {
		System.out.println(Arrays.deepToString(ee));
	}
	
	
	public Coordinate Make_Decision() {
		Coordinate coor = new Coordinate(0, 0);
		System.out.println("Evaluate grid: ");
		int [][] ee =Get_Mark();
		int max = ee[ee.length/2][ee[0].length/2];
		int max_row=ee.length/2;
		int max_col=ee[0].length/2;
		
		//if the values are equal, prefer to set in the middle first.
		for(int i=0;i<ee.length;i++) {
			for(int j=0;j<ee[0].length;j++) {
				if(ee[i][j]>max) {
					max = ee[i][j];
					max_row=i;
					max_col=j;
				}
			}
		}
		Show_Board_value(ee);
		
		
		coor.col=max_col;
		coor.row=max_row;
		return coor;
	}

	public int Make_Decision_Bottom() {
		int [] ee = Get_Mark_Bottom();
		int max=0;
		int cur_col=0;
		for(int i=0;i<ee.length;i++) {
			if(ee[i]>max) {
				max=ee[i];
				cur_col=i;	
			}
		}
		return cur_col;
	}
	
	
	public int[][] Get_Mark() {
		int[][] values = new int[row][col];
		for (int i = 0; i < Student_Board.size(); i++) {
			for (int j = 0; j < Student_Board.get(0).size(); j++) {		
				values[i][j] = evaluate(i, j);
			}
		}
		return values;
	}
	
	public int[] Get_Mark_Bottom() {
		int [] values = new int[col];
		for(int i=0;i<Student_Board.get(0).size();i++) {
			
			int cur_row =FindRow(i);
			//when this col is full, set the value as -1, which can not be selected by the make decision function
			if(cur_row==-1) {
				values[i]=-1;
			}else {
				values[i]=evaluate(i, FindRow(i));
			}
		}
		return values;
	}
	
	public int FindRow(int col_cur){
		int result =row-1;
		while(result>=0&&Student_Board.get(result).get(col_cur)!=0) {
			result--;
		}
		//this col is full
		if(result==-1) {
			return -1;
		}
		System.out.println("currently row is : ");
		System.out.println(result);
		return result;
	}
	

	public int evaluate(int row_cur, int col_cur) {
		if(Student_Board.get(row_cur).get(col_cur) !=0) {
			return 0;
		}
		int horizon = 1;
		int vertical = 1;
		int dia_left45 = 1;
		int dia_right45 = 1;

		int row_temp;
		int col_temp;

		// horizon ++
		row_temp = row_cur;
		col_temp = col_cur;
		col_temp++;
		while (inBound(row_temp, col_temp)) {
			if (Student_Board.get(row_temp).get(col_temp) == 1) {
				col_temp++;
				horizon = horizon * 10;
			} else {
				break;
			}
		}

		// horizon --
		row_temp = row_cur;
		col_temp = col_cur;
		col_temp--;
		while (inBound(row_temp, col_temp)) {
			if (Student_Board.get(row_temp).get(col_temp) == 1) {
				col_temp--;
				horizon = horizon * 10;
			} else {
				break;
			}
		}

		// vertical++
		row_temp = row_cur;
		col_temp = col_cur;
		row_temp++;
		while (inBound(row_temp, col_temp)) {
			if (Student_Board.get(row_temp).get(col_temp) == 1) {
				row_temp++;
				vertical = vertical * 10;
			} else {
				break;
			}
		}

		// vertical--
		row_temp = row_cur;
		col_temp = col_cur;
		row_temp--;
		while (inBound(row_temp, col_temp)) {
			if (Student_Board.get(row_temp).get(col_temp) == 1) {
				row_temp--;
				vertical = vertical * 10;
			} else {
				break;
			}
		}

		// dia_left45++
		row_temp = row_cur;
		col_temp = col_cur;
		row_temp--;
		col_temp++;
		while (inBound(row_temp, col_temp)) {
			if (Student_Board.get(row_temp).get(col_temp) == 1) {
				row_temp--;
				col_temp++;
				dia_left45 = dia_left45 * 10;
			} else {
				break;
			}
		}
		// dia_left45--
		row_temp = row_cur;
		col_temp = col_cur;
		row_temp++;
		col_temp--;
		while (inBound(row_temp, col_temp)) {
			if (Student_Board.get(row_temp).get(col_temp) == 1) {
				row_temp++;
				col_temp--;
				dia_left45 = dia_left45 * 10;
			} else {
				break;
			}
		}

		// dia_right45++
		row_temp = row_cur;
		col_temp = col_cur;
		row_temp++;
		col_temp++;
		while (inBound(row_temp, col_temp)) {
			if (Student_Board.get(row_temp).get(col_temp) == 1) {
				row_temp++;
				col_temp++;
				dia_left45 = dia_right45 * 10;
			} else {
				break;
			}
		}
		// dia_right45--
		row_temp = row_cur;
		col_temp = col_cur;
		row_temp--;
		col_temp--;
		while (inBound(row_temp, col_temp)) {
			if (Student_Board.get(row_temp).get(col_temp) == 1) {
				row_temp--;
				col_temp--;
				dia_left45 = dia_right45 * 10;
			} else {
				break;
			}
		}
		
		int value = horizon+vertical+dia_right45+dia_left45;
		return value;
	}

	//bound judgement
	public boolean inBound(int row_cur, int col_cur) {
		if (row_cur < Student_Board.size() && row_cur >= 0 && col_cur < Student_Board.get(0).size() && col_cur >= 0) {
			return true;
		}
		return false;
	}
}