
public class getMark {
	
}
